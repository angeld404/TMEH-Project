/**
 *  delay_us.h
 *
 *  Jonathan Lau, Angel Delgado
 *  CPE 329 Spring 2019
 *  Professor Hummel
 *
 */

#include "msp.h"

#ifndef DELAY_US_H
#define DELAY_US_H_

void delay_us(int time_us); //Function Declarations


#endif
